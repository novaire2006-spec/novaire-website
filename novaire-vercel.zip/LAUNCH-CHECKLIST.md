# Interne Freigabe — nicht Bestandteil der öffentlichen Website

## Blocker vor öffentlicher Verwendung der Rechtstexte

- [ ] Tatsächlichen alleinigen Betreiber und die Rechtsform bestätigen. Nutzer
  möchte Armin Brnicanin als Betreiber; eine bestehende gemeinsame Tätigkeit
  mit Christian und mögliche Rechte/Verträge sind damit nicht automatisch beendet.
- [ ] Gewerbeanmeldung und ggf. Pflichtangaben vervollständigen. „CEO“ ist kein
  Rechtsformnachweis. Keine USt-IdNr., Registereinträge oder Firmengründung erfinden.
- [ ] Nutzungs-/Markenrechte an Novaire und KI-generiertem Logo prüfen. Die
  Umbenennung allein beweist keine Markenfreiheit. Logo-Generator und dessen
  Bedingungen sind bisher unbekannt. Rechte an Provider-Logos prüfen.
- [ ] Supportpostfach wirklich testen. IONOS-Vertrag und Zugriff auf das Postfach
  bestätigen; nur erforderliche und berechtigte Personen erhalten Zugriff.
- [ ] Vercel-Vertrag/AVV, Protokolle, Löschfristen, Drittlandübermittlungen und
  tatsächliche Hosting-Einstellungen bestätigen. Nicht allein die Privacy Policy
  des Hosting-Anbieters als eigene vollständige Datenschutzerklärung behandeln.
- [ ] Supabase, OpenAI, Anthropic, RevenueCat, Apple und ggf. weitere tatsächlich
  eingesetzte Dienste inventarisieren: Rechtsname, Rolle, Daten, Zweck, Rechtsgrundlage,
  Region, Aufbewahrung, Auftragsverarbeitung, Unterauftragnehmer, Transfermechanismus.
- [ ] App-Datenschutz nicht nur anhand des lokalen Codes abschließend behaupten.
  Live-Konfiguration, Verträge, Trainings-/Audio-Einstellungen und Logs prüfen.
- [ ] Umgesetztes Löschkonzept für Chat, Dateien, Konto, Audio, Backups, Lernprofile,
  Support und Kaufnachweise bestätigen; keine erfundenen 30-/90-Tage-Fristen.
- [ ] Mindestalter 10 / Klassen 5–13: Kinderprozess, Sorgeberechtigten-Verifizierung,
  Nachweis, Widerruf und altersgerechte Informationen fachlich prüfen. Die zwei
  Schüler-Häkchen im derzeitigen Onboarding sind keine belegte Elternverifizierung.
- [ ] Minderjährigenverträge gesondert prüfen, besonders kostenpflichtige Abos.
- [ ] Datenschutz-Folgenabschätzung und Schutzmaßnahmen wegen Minderjährigen,
  KI-Verarbeitung und Lernprofilbildung prüfen, einschließlich Profiling-Transparenz.
- [ ] Nova-Laufzeiten, Preise und Kontingente bestätigen. 24h-Aktivierungszeitpunkt,
  Präsentationsanzahl, 24h-Bearbeitung und dauerhafter Zugriff rechtlich/technisch abgleichen.
- [ ] Vertragsschluss, Verbraucherinformationen, Widerrufsbelehrung/Musterformular,
  Kündigung, Erstattung, Apple-Rollen und Rechte bei digitalen Produkten prüfen.
- [ ] Pflichtinformationen zur Verbraucherstreitbeilegung prüfen. Kein veralteter
  Link zur früheren EU-OS-Plattform wurde eingefügt.
- [ ] Rechtstexte professionell prüfen lassen. Dieser Code macht keinen Betrieb
  allein durch Formulierungen „DSGVO-konform“.

## Technische Veröffentlichungsfreigabe

- [ ] Aktuelle App-Bilder bestätigen. Export zeigt echtes UI mit Demo-Profil;
  vorhandener Lernrückblick stammt aus einem früheren Entwicklungsstand.
- [ ] App-Funktionalität insbesondere Nova Live testen, bevor Beta-Hinweise
  oder Entwicklungskennzeichnung entfernt werden.
- [ ] Offiziellen App-Store-Link ergänzen, sobald tatsächlich vorhanden.
- [ ] Support und Rechtslinks in der App später auf novaireai.de umstellen.
  Aktuell stehen im Onboarding noch mylenova.de/datenschutz und /agb. Im Rahmen
  dieses Website-Auftrags wurden App-Dateien ausdrücklich nicht verändert.
- [ ] Mobile Safari am echten iPhone testen; Browser-QA ersetzt keinen Gerätetest.
- [ ] Nach Rechtstextfreigabe die sichtbaren Entwurfskennzeichnungen gezielt entfernen,
  Meta-Robots und X-Robots-Tag in vercel.json ändern, robots.txt freigeben sowie
  Canonical-URLs/Sitemap mit bestätigter primärer Domain ergänzen.
  **noindex ist kein Zugriffsschutz.** Vorschauen mit Vercel Deployment Protection
  schützen, sofern verfügbar; keine bloße Suchmaschinensperre als privat ansehen.
- [ ] Keine Vercel Analytics, Drittanbieter-Schriften oder Marketing-Tools nachträglich
  ohne neue Datenschutzprüfung aktivieren. CSP gegebenenfalls bewusst aktualisieren.

## Quellen (am 30.09.2026 geprüft)

- DDG § 5: https://www.gesetze-im-internet.de/ddg/__5.html
- DSGVO, insbesondere Art. 8, 13, 15–22, 28, 35 und 44 ff.:
  https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:32016R0679
- BfDI Gesetzestexte: https://www.bfdi.bund.de/SharedDocs/Downloads/DE/Broschueren/INFO1.pdf
- BGB § 107/108: https://www.gesetze-im-internet.de/bgb/__107.html
- Vercel: https://vercel.com/legal/dpa und https://vercel.com/legal/privacy-notice
- IONOS: https://www.ionos.de/hilfe/datenschutz
- OpenAI Marken: https://openai.com/brand/

## Nur lokal gelesene technische Hinweise

- supabase/functions/chat/index.ts: Anthropic Claude Sonnet/Haiku,
  OpenAI GPT, Mathe-/Bildrouting. Konstanten allein wurden nicht als aktive
  Live-Produktgarantie interpretiert.
- supabase/functions/live-orb-session/session.json: OpenAI-Sprachkonfiguration;
  tatsächliche Verbindungsqualität im Auftrag nicht verifiziert.
- lib/screens/onboarding_screen.dart: zwei Bestätigungen für Eltern und
  Datenschutz/AGB; kein geprüfter Sorgeberechtigten-Nachweis.
- Keine Datenbankabfragen oder Deployments in diesem Auftrag.
