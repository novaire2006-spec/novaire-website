# Novaire — Website

Eigenständige statische HTML-/CSS-/JavaScript-Website. Keine Änderungen an der
Flutter-App, keine Backend-Verbindung, kein Framework und keine Runtime-Pakete.

## Ansehen

`public/index.html` direkt im Browser öffnen, oder im Terminal:

```sh
cd /Users/armindaniel/Dev/premium_app/website
npm run build
npm run preview
```

Dann `http://127.0.0.1:4173` öffnen. Mit Ctrl+C beenden.

## Auf Vercel bereitstellen

Zunächst nur als geschützte Vorschau bereitstellen. Noch keine rechtlich
freigegebene Produktionsfassung; siehe `LAUNCH-CHECKLIST.md`.

1. Das Repository in Vercel importieren (oder dieses Verzeichnis als eigenes
   Repository verwenden).
2. **Root Directory:** `website`, wenn das gesamte App-Repository importiert
   wurde; sonst das Wurzelverzeichnis des separaten Website-Repositories.
3. **Framework Preset:** `Other`.
4. **Build Command:** `node tools/build.mjs`.
5. **Output Directory:** `public`.
6. Keine API-Schlüssel und keine Environment-Variablen erforderlich.
7. Vorschau prüfen. Erst nach Abschluss der Freigabe-Checkliste unter
   Settings → Domains `novaireai.de` und `www.novaireai.de` hinzufügen.
   Die von Vercel für DEIN Projekt angezeigten DNS-Einträge beim Domainanbieter
   setzen. Bestehende IONOS-MX-, SPF-, DKIM- und DMARC-Einträge für E-Mail nicht
   entfernen. Keine Domain oder DNS-Konfiguration wurde von uns verändert.

Vercel liest zusätzlich `vercel.json`: statische Ausgabe, saubere URLs,
Sicherheitsheader und derzeit `noindex`. Nur `public` wird veröffentlicht,
niemals Flutter-Code, interne Prüfdokumente oder Zugangsdaten.

Offizielle Anleitung: https://vercel.com/docs/builds/configure-a-build

## Dateien bearbeiten

- `public/index.html`: Startseite, Texte, Sektionen, Screenshot-Reihenfolge.
- `public/styles.css`: Farben, Abstände, Typografie, responsive Darstellung,
  einmaliger Lichtreflex auf dem unveränderten Original-Logo.
- `public/app.js`: Menü, einmalige Scroll-Einblendungen, Bildansicht. Keine
  Cookies, Tracking, Speicherzugriffe oder Netzwerkanfragen.
- `tools/legal-content.mjs`: Inhalt der einfachen Textseiten. Danach
  `npm run build` ausführen; erzeugt `public/{impressum,datenschutz,agb,support}.html`.
- `public/assets`: alle Bilder und Anbieter-Logos lokal.
- `vercel.json`: Deployment-/Sicherheitskonfiguration.

Das Originalbild enthält bereits den exakten NOVAIRE-Schriftzug. Er wurde
nicht mit einer ähnlichen Schrift nachgebaut. Die restliche Website verwendet
native Systemschriften, ohne einen externen Font-Dienst aufzurufen.

## Bewusste Grenzen der ersten Fassung

- Noch kein App-Store-Link: „Bald für iOS“, kein erfundener Download.
- Keine Preise oder Verkaufsaktionen: finale Produktkonditionen fehlen.
- Nova Live ist als Funktion in Entwicklung bezeichnet; ein funktionierender
  Audio-Dialog wurde im Rahmen dieses Website-Auftrags nicht geprüft.
- KI-Tabelle zeigt OpenAI/GPT und Anthropic/Claude, basierend auf lokalem Code.
  Keine behauptete Partnerschaft und kein Nachweis der aktuellen Live-Konfiguration.
- „Ab 10“ ist als geplanter Start gekennzeichnet. Die Website ändert keine
  Altersfreigabe oder Einwilligungslogik der App.
- Rechtstexte sind **sichtbar als Arbeitsentwürfe markiert**. Nicht ungeprüft als
  verbindliche AGB oder vollständige Datenschutzerklärung veröffentlichen.

## Tests

```sh
npm run build
npm test
node --check public/app.js
```

Optionaler Browser-Test (Playwright in der lokalen Entwicklungsumgebung,
nicht als Website-Abhängigkeit): Preview starten und
`node tools/browser-check.cjs` ausführen. Ein externer vorhandener Playwright-
Installationspfad kann über `PLAYWRIGHT_PATH` angegeben werden.
Der Test prüft 320/390/768/1440 Pixel, alle Seiten, Bilder, Navigation, Dialog,
Escape/Fokus, Betrieb ohne JavaScript, reduzierte Bewegung, Intro-Endzustand
sowie Cookies, externe Requests und Browserfehler. Bilder entstehen in `qa/`.

Die drei neuen App-Aufnahmen lassen sich offline neu exportieren:

```sh
cd /Users/armindaniel/Dev/premium_app
flutter test website/test/capture_app_test.dart \
  --dart-define=PREVIEW_FONTS=/Users/armindaniel/Dev/flutter/bin/cache/artifacts/material_fonts
```

Der Export verwendet Produktionswidgets, lokale Testdaten (Tessa, NRW) und
ein Mock-Backend. Keine echten Kontodaten, keine Live-Anfragen. Roboto wird
im Headless-Renderer als Preview-Schrift geladen; das Betriebssystem kann
die App auf einem echten iPhone typografisch leicht anders darstellen.

Die Website wurde **nicht veröffentlicht**. Keine Käufe, Backend-Änderungen,
Gewerbeanmeldungen, DNS-Änderungen oder App-Store-Einreichungen vorgenommen.
