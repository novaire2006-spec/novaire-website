// Website-only test asset exporter. Uses production widgets and an offline demo
// profile; does not change app state, real accounts, or production source.
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:premium_app/models/onboarding_draft.dart';
import 'package:premium_app/providers/profile_provider.dart';
import 'package:premium_app/screens/home_screen.dart';
import 'package:premium_app/screens/onboarding_screen.dart';
import 'package:premium_app/widgets/onboarding_controls.dart';
import 'package:premium_app/widgets/onboarding_figure.dart';
import 'package:premium_app/widgets/universe_prelude.dart';

class DemoProfile extends ProfileProvider {
  @override
  String get displayName => 'Tessa';
  @override
  Future<void> initialize() async {}
  @override
  Future<void> refresh() async {}
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: 'https://website-demo.supabase.co', anonKey: 'offline-demo', debug: false,
      httpClient: MockClient((_) async => http.Response('[]', 200)),
      authOptions: const FlutterAuthClientOptions(autoRefreshToken: false,
        detectSessionInUri: false, localStorage: EmptyLocalStorage()),
    );
    const directory = String.fromEnvironment('PREVIEW_FONTS');
    if (directory.isEmpty) throw StateError('PREVIEW_FONTS is required');
    for (final family in ['Roboto', 'Ahem', 'SpacePreview', '.SF UI Text', '.SF UI Display', '.SF Pro Text', '.SF Pro Display', 'CupertinoSystemText', 'CupertinoSystemDisplay']) {
      final font = FontLoader(family)..addFont(File('$directory/Roboto-Regular.ttf').readAsBytes().then(ByteData.sublistView));
      await font.load();
    }
    await (FontLoader('MaterialIcons')..addFont(File('$directory/MaterialIcons-Regular.otf').readAsBytes().then(ByteData.sublistView))).load();
    await (FontLoader('packages/cupertino_icons/CupertinoIcons')..addFont(rootBundle.load('packages/cupertino_icons/assets/CupertinoIcons.ttf'))).load();
    await OnboardingFigure.warmUp();
    await GermanStateShape.load();
  });
  tearDownAll(() => Supabase.instance.dispose());

  Future<void> mount(WidgetTester tester, Widget child) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(RepaintBoundary(key: const ValueKey('website-capture'), child:
      ChangeNotifierProvider<ProfileProvider>(create: (_) => DemoProfile(), child:
        MaterialApp(debugShowCheckedModeBanner: false,
          theme: ThemeData(brightness: Brightness.dark, fontFamily: 'SpacePreview'),
          home: child))));
    await tester.pump();
    await tester.runAsync(() async {
      for (final element in find.byType(Image).evaluate()) {
        await precacheImage((element.widget as Image).image, element);
      }
    });
    await tester.pump();
    for (int i = 0; i < 30; i++) { await tester.pump(const Duration(milliseconds: 100)); }
  }
  Future<void> capture(WidgetTester tester, String name) async {
    await tester.runAsync(() async {
      for (final element in find.byType(Image).evaluate()) {
        await precacheImage((element.widget as Image).image, element);
      }
    });
    await tester.pump();
    // Flutter's headless renderer otherwise uses the square-glyph Ahem font
    // for font-family-less button spans. Supply the preview font at the render
    // root only; explicit icon fonts and all production widget styles survive.
    for (final element in find.byType(RichText).evaluate()) {
      final paragraph = element.renderObject as RenderParagraph;
      paragraph.text = TextSpan(style: const TextStyle(fontFamily: 'SpacePreview'), children: [paragraph.text]);
    }
    await tester.pump(const Duration(milliseconds: 400));
    final boundary = tester.renderObject<RenderRepaintBoundary>(find.byKey(const ValueKey('website-capture')));
    await tester.runAsync(() async {
      final image = await boundary.toImage(pixelRatio: 2);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      final directory = Directory('website/public/assets')..createSync(recursive: true);
      await File('${directory.path}/$name.png').writeAsBytes(bytes!.buffer.asUint8List());
      image.dispose();
    });
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 15));
  }
  testWidgets('capture real rocket onboarding', (tester) async {
    SharedPreferences.setMockInitialValues({});
    await mount(tester, Scaffold(backgroundColor: Colors.black, body: UniversePrelude(onStart: () {})));
    await tester.pump(const Duration(seconds: 4));
    await tester.pump(const Duration(milliseconds: 600));
    await capture(tester, 'onboarding-rocket');
  });
  testWidgets('capture real Bundesland onboarding', (tester) async {
    SharedPreferences.setMockInitialValues({OnboardingDraftStore.key: jsonEncode(
      const OnboardingDraft(nickname: 'Tessa', age: '15', parents: true, privacy: true,
        step: 9, state: 'Nordrhein-Westfalen').toJson())});
    await mount(tester, const OnboardingScreen());
    await capture(tester, 'onboarding-state');
  });
  testWidgets('capture actual chat empty state with demo name', (tester) async {
    SharedPreferences.setMockInitialValues({'ai_nickname': 'Tessa'});
    await mount(tester, const HomeScreen());
    final nova = find.text('Nova');
    await tester.tap(nova.last);
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    FocusManager.instance.primaryFocus?.unfocus();
    await tester.pump(const Duration(seconds: 1));
    await capture(tester, 'chat-welcome');
  });
}
