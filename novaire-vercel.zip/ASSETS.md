# Bildherkunft

Alle Medien werden lokal ausgeliefert. Keine Hotlinks oder externen Font-Aufrufe.

| Datei in public/assets | Herkunft |
| --- | --- |
| novaire-logo.png | Vom Nutzer geliefertes KI-generiertes Original 51C38B6C-BE83-4C37-9689-8A675161995F.PNG, unverändert kopiert. Generator/Lizenz noch prüfen. |
| chat-welcome.png | HomeScreen aus Flutter, tatsächlicher Empty State, fiktives Beispielprofil Tessa, offline über test/capture_app_test.dart gerendert. |
| onboarding-rocket.png | Tatsächliches UniversePrelude-Widget und vorhandenes Raketen-Asset, offline gerendert. |
| onboarding-state.png | Tatsächlicher OnboardingScreen, Schritt 9, Demo-Auswahl Nordrhein-Westfalen, offline gerendert. Kartenherkunft siehe assets/onboarding/SOURCES.md im App-Repository. |
| orb.png | Vorhandener Produktionswidget-Export design/marketing/lenova-ad/assets/orb-reference.png. |
| learning-report.png | Vorhandener App-UI-Export design/marketing/lenova-ad/assets/lenova-learning-report.png. |
| openai.svg | Simple Icons v13.21.0, https://raw.githubusercontent.com/simple-icons/simple-icons/13.21.0/icons/openai.svg; einfarbige Darstellung über CSS. |
| anthropic.svg | Simple Icons, https://cdn.simpleicons.org/anthropic/ffffff; abgerufen 30.09.2026. |

Simple Icons: https://github.com/simple-icons/simple-icons (CC0 für die Sammlung;
Markenrechte bleiben unberührt). Anbieter-Logos kennzeichnen die technische
Verwendung und implizieren keine Partnerschaft. Vor öffentlichem Einsatz mit
aktuellen offiziellen Markenrichtlinien abgleichen.

Kein SVG-Nachbau des KI-generierten Novaire-Symbols; die Original-Wortmarke
bleibt im Hero erhalten. Der Lichtreflex ist ein CSS-Effekt auf einer zweiten
Darstellung desselben Bildes. Bei reduzierter Bewegung bleibt das Logo statisch.
