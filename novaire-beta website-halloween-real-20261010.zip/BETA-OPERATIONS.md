# Novaire Beta — Betrieb und Übergabe

Stand: 10.10.2026. Website-Update lokal fertig; noch nicht auf Vercel ausgerollt.
Backend im bestehenden Projekt `Lenova` (`naafzrrhjsfaqqrnhrcn`) mit Freigabe
veröffentlicht. Keine bestehenden App-Nutzer, Chats oder Lernstände verändert.

## Bewerbungen ansehen

1. https://supabase.com/dashboard/project/naafzrrhjsfaqqrnhrcn/editor öffnen.
2. Schema `public`, Tabelle `website_beta_applications` auswählen.
3. Nach `created_at` sortieren oder `status` filtern. Neue Einträge haben `new`.
4. `admin_notes` für notwendige kurze interne Notizen verwenden; keine unnötigen
   sensiblen Angaben. `shortlisted` = engere Auswahl, `invited` = eingeladen,
   `rejected` = nicht ausgewählt, `withdrawn` = zurückgezogene Bewerbung.
5. Bei unter 16: Elternzustimmung tatsächlich prüfen, dann `guardian_verified`
   bestätigen. Die Datenbank lehnt `invited` ohne diese Bestätigung ab.
6. Einladung/Antwort selbst über das Supportpostfach schicken. Es gibt keinen
   automatischen Mailversand und keine automatische Erstellung von App-Konten.

Der Checkbox-/Eltern-Mail-Prozess beweist noch keine Sorgeberechtigung. Die
organisatorische Prüfung liegt beim Betreiber. Rund 50 Plätze sind eine
Zielgröße, keine Zusage, kein automatisches First-come-first-served-Limit.

Pro Kontaktadresse und Kampagne existiert ein Eintrag. Wiederholungen oder
veränderte Angaben mit derselben Mail/Request-ID überschreiben die ursprüngliche
Bewerbung nie. Alle gültigen Wiederholungen erhalten denselben neutralen
Empfangsbeleg, damit keine E-Mail-Existenz offengelegt wird. Geschwister und
Korrekturen über Support bearbeiten; dieser Hinweis steht im Formular.

`withdrawn` allein löscht keine Daten. Bei berechtigter Löschanfrage genau den
zugehörigen Eintrag im Table Editor löschen. Für Auskunft/Widerruf die Person
angemessen identifizieren, z. B. über die angegebene Kontaktadresse; kein
öffentlicher Such-/Lösch-Endpunkt und keine Login-Passwörter erfragen.

## Frist und Aufbewahrung

- Schluss am `2026-10-30T23:00:00Z`, also nach dem gesamten 30. Oktober in Berlin.
  Edge Function und Datenbank prüfen unabhängig die Serverzeit.
- Bewerbungen werden am `2027-01-28T23:00:00Z` zur Löschung fällig (90 Tage).
- Bestehendes `pg_cron` führt `novaire-beta-halloween-2026-cleanup` täglich
  `10 1 * * *` UTC aus. Es löscht nur abgelaufene Beta-Einträge und Rate-Buckets.
- Missbrauchskennwerte verfallen nach sieben Tagen; täglicher Cleanup kann bis
  zum nächsten Lauf dauern. Anbieter-Logs/Backups haben separate Lebenszyklen.
- Bestehender Job `lenova-expire-nova-access` unverändert.

Nach Fristende lassen Frontend und Backend keinen neuen Versand zu. Der
Countdown läuft nicht negativ. Eine falsch eingestellte lokale Uhr kann den
angezeigten Countdown beeinflussen, aber nicht die serverseitige Frist umgehen.

## Zugriff und Spam-Schutz

Endpoint: `https://naafzrrhjsfaqqrnhrcn.supabase.co/functions/v1/beta-application`.
Aktiv: Deployment-Version 2, Codeheader `2026-10-10-beta-v2`.

Absichtlich öffentliches JSON-POST-Gateway (`verify_jwt=false`, ausdrücklich
freigegeben). Keine Auth-/Provider-Secrets im Browser und kein öffentliches
REST-Leserecht. Die vorhandenen `SUPABASE_URL` und
`SUPABASE_SERVICE_ROLE_KEY` werden nur in der Edge-Laufzeit benutzt; keine neuen
Secrets nötig. Diese Werte weder im Website-Repo noch im Chat eintragen.

Zwei neue Tabellen haben RLS und FORCE RLS, keine App-Policies und keine Grants
an `anon`/`authenticated`. Das ist eine absichtliche Backend-only-Sperre.
Parameterisierte `SECURITY INVOKER`-RPCs sind nur für `service_role` freigegeben.
Servervalidierung begrenzt Body auf 16 KiB, Textlängen, Alter/Enums und Felder;
unbekannte Adminfelder werden abgelehnt. Body-Lesezeit maximal 5 s, DB-Request
8 s, Browser-Timeout 15 s. Kein aktiver HTML-Inhalt aus Freitexten.

CORS erlaubt genau die beiden Novaire-Domains sowie `localhost:4173` und
`127.0.0.1:4173` für Entwicklung. Es erlaubt kein `null`/`file://` und keine
beliebigen Vercel-Preview-Hosts. CORS ist kein Bot-/Identitätsnachweis.

Atomare SQL-Grenzen: fünf gültige Anfragen je abgeleitetem IP-Bucket/Stunde,
3.000 pro UTC-Tag insgesamt; Wiederholungen zählen mit. Globaler Zähler wird vor
dem IP-Bucket begrenzt, um auch bei wechselnden Adressen die Tabellen zu begrenzen.
Honeypot gibt neutralen Beleg zurück, ohne Bewerbungsdaten zu speichern.

Der erste Live-Test belegte, dass X-Forwarded-For am Gateway ungeeignet war.
Korrigiert auf ausschließlich `cf-connecting-ip` vom vorhandenen Hosted-Gateway,
IPv4/IPv6 validiert und normalisiert. Fehlender/ungültiger Header führt zu 503,
nicht zu einem gemeinsamen „unknown“-Bucket. HMAC mit Zweck/Stunde verhindert
unveränderte IP-Speicherung. Header ist Missbrauchssignal, keine Authentifizierung.
Live-Probe: XFF/Real-IP änderten den Bucket nicht; gefälschtes CF-Header wurde
am Gateway mit 403 blockiert. Diese Annahme nicht auf ungeschütztes Self-Hosting
übertragen. Schul-/Familiennetze oder Worker können ein Limit teilen; bei
Problemen Supportalternative nutzen. Das ist kein CAPTCHA oder Mail-Verifizierung.

Quellen: https://developers.cloudflare.com/fundamentals/reference/http-headers/
und https://supabase.com/docs/guides/observability/log-field-reference.

## Migration / reproduzierbare Prüfungen

Migration: `supabase/migrations/20261010100630_website_beta_applications.sql`;
Timestamp an tatsächlich aufgezeichnete Live-Version angeglichen. Keine
bestehenden Tabellen/Policies ersetzt. Cron benutzt vorhandene Infrastruktur.

Aus Repository-Wurzel mit Deno:

```sh
deno check supabase/functions/beta-application/index.ts
deno test supabase/functions/beta-application/handler_test.ts
deno run --allow-read --allow-env --allow-sys supabase/functions/beta-application/sql_test.ts
```

Letzter Befehl prüft reale PostgreSQL/WASM-Semantik in einer wegwerfbaren lokalen
PGlite-DB; nur `pg_cron` ist dabei ein Test-Dummy. SQL-Fixtures rollen zurück.
`supabase/tests/website_beta_applications.sql` ist für diese frische lokale DB,
nicht unbesehen gegen ein Projekt mit realen Bewerbungen ausführen: Rate-/Zähltests
setzen eine isolierte Umgebung voraus. Live wurde vor Freischaltung ein
separater zurückgerollter DML/Rollen-Test durchgeführt, ohne temporäre Grants.

Live-Tests nur nach Freigabe; sie erzeugen künstliche `.invalid`-Einträge:

```sh
deno run --allow-net supabase/functions/beta-application/live_check.ts --run
cd website
PLAYWRIGHT_PATH=/Pfad/zu/playwright node tools/beta-live-check.cjs --run
```

Nachher ausschließlich die ausgegebenen synthetischen `requestId`s entfernen,
keine Tabelle leeren. Ein bereits verbrauchtes IP-Limit kann einen erneuten
Test blockieren; nicht produktive Zähler anderer Anfragen zurücksetzen.

## Tatsächlich ausgeführte Tests am 10.10.2026

Beim anschließenden Halloween-Feinschliff wurden nur Website-Markup, CSS,
lokale SVGs und Formular-Hinweistexte geändert. Keine Migration oder erneutes
Backend-Deployment. Read-only geprüft: FORCE RLS und fehlende SELECT-Grants
für beide Bewerbungstabellen sowie echte CORS-Preflight-Antwort für
`https://www.novaireai.de` (204, Codeversion `2026-10-10-beta-v2`).
Neue lokale Regression: 19 Node-Tests und 15 Chromium-Prüfgruppen;
Dekoration ohne horizontalen Overflow oder blockierte Controls bei allen vier
Breiten, lockerer Motivationstext und ehrlicher grüner Empfangsbeleg geprüft.
Formularantworten dabei gemockt; keine weiteren Live-Bewerbungen erzeugt.
Weiteres rein visuelles Update am selben Tag: drei eigens mit Imagegen erzeugte
fotorealistische Motive als transparente, komprimierte WebP-Dateien statt der
flachen SVG-Motive. Lokal erzeugte kleine weiße, gelbe und blaue Sterne nur auf
Start-/Beta-Seite, Bewegungseinstellungen respektiert. Lokal lizenzierte
Creepster-Schrift ausschließlich für „Endet vor Halloween — damit ihr feiern
könnt.“ Die Frist und sämtliche Backend-Verträge unverändert. WebP-/Font-MIME
der lokalen Vorschau ergänzt. Neue Regression: 21 Node-Tests und 17 Browser-
Prüfgruppen, einschließlich echter Bild-/Alpha- und Font-Dekodierung, strikter
CSP, unveränderter Systemschrift für Formulare und sauberer Infoseiten.
Auch hier ausschließlich Mock-Formularantworten, keine Live-Schreibzugriffe.
Bildherkunft und exakte Prompts stehen in `HALLOWEEN-ASSETS.md`.

Die folgenden Backend-/Live-Tests stammen aus der ursprünglichen Integration:

- 17 Node-Tests: Frist/Validierung, 7 HTML-Seiten, Links/Assets, keine sichtbaren
  Redaktion-/Entwurfsnotizen, keine Secrets/Tracker, CSP und lokale Dekoration.
- 14 Chromium-Prüfgruppen: 7 Seiten × 320/390/768/1440, Navigation/Dialog/Fokus,
  kein JS, Elternprozess, normales Textinput statt HTML-Ausführung, Doppelversand,
  202 nur mit `accepted:true`, 503/429 Retry ohne Datenverlust, 410/Frist.
  Diese Fehlerantworten waren absichtlich gemockt. Keine unerwarteten externen
  Requests, Cookies, Local/Session Storage oder Browserfehler.
- 16 Deno-Tests: Eingaben/CORS/Deadline, Bodylimits inklusive langsamer Streams,
  DB-Ausfälle, Duplikate, CF-only-HMAC, ungültiger Gateway-Header. Typecheck/Lint.
- PostgreSQL/WASM: zwei verschiedene Auth-Identitäten und anon ohne CRUD/RPC,
  zusätzlich lokale RLS-Abwehr bei versehentlichen Grants; Service-Speicherung,
  unveränderlicher Empfang, Kollisionen, Elternprüfung, atomare Limits, Cleanup.
- Live-Postgres: Rollen-/CRUD-/RPC-Sperren und Service-Funktionen per ROLLBACK;
  FORCE RLS/fehlende öffentliche Grants sowie tatsächlicher Cronjob geprüft.
- 18 echte HTTP-Prüfungen: CORS/Method/Validation/413, echte Erwachsenen- und
  Elternbewerbung, E-Mail-/ID-Duplikate ohne Überschreiben, 429, CF-/XFF-/Real-IP-
  Spoof-Proben. Zwei Einträge kontrolliert und danach entfernt.
- Echter mobiler Chromium-Formularversand ohne Mock: lokal mit tatsächlicher
  CSP → Supabase → gespeicherter Eintrag → echte Erfolgsansicht. Auch diese
  einzelne künstliche Bewerbung kontrolliert und entfernt.
- Anonyme REST-Aufrufe: SELECT/INSERT/UPDATE/DELETE und Cleanup-RPC abgewiesen;
  SELECT lieferte 401 / `42501` (Tabellenberechtigung fehlt).
- Sicherheitsberater: keine neuen WARNs; zwei INFOs „RLS ohne Policy“ sind
  beabsichtigte private Tabellen. Vorhandene Auth-/SECURITY-DEFINER-Warnungen
  anderer Funktionen unverändert, nicht Bestandteil dieser Website-Änderung.

Nicht getestet: echter iPhone-Safari-Versand, Vercel-Deployment dieses Updates,
TestFlight-Einladungen und funktionierendes Supportpostfach. Rechtsprüfung und
Betreiber-/AVV-Freigaben sind keine technischen Testergebnisse.
