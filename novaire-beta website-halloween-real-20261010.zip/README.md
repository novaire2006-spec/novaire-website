# Novaire — Website

Statische HTML-/CSS-/JavaScript-Website mit separater Beta-Bewerbungsseite.
Kein Framework, keine Runtime-Pakete, keine Änderungen an der Flutter-App.
Das Formular sendet ausschließlich an den vorhandenen Supabase-Backend-Endpunkt.

## Lokal ansehen

```sh
cd /Users/armindaniel/Dev/premium_app/website
npm run build
npm run preview
```

Öffne http://127.0.0.1:4173/beta.html. Mit Ctrl+C beenden. Die neue Seite
braucht HTTP: ES-Module funktionieren beim direkten Öffnen über `file://`
nicht zuverlässig. Ohne JavaScript bleibt das Formular gesperrt und zeigt
die Mailalternative; Frist und Teilnahmebedingungen bleiben lesbar.

## Aktualisierung auf Vercel

Diese Änderung wurde noch nicht auf Vercel veröffentlicht. Das Beta-Backend
wurde mit ausdrücklicher Freigabe im vorhandenen Supabase-Projekt eingerichtet.
Vor Veröffentlichung die interne `LAUNCH-CHECKLIST.md` prüfen.

1. Canonical Website-Dateien aus diesem Verzeichnis verwenden, nicht die alten
   Exportkopien `novaire-vercel*` oder eine ZIP-Datei als einzige Repo-Datei.
2. Root Directory `website`, wenn das vollständige App-Repo importiert wird;
   sonst das Wurzelverzeichnis des eigenständigen Website-Repositories.
3. Framework `Other`, Build Command `node tools/build.mjs`, Output `public`.
4. Keine API-Schlüssel und keine Website-Environment-Variablen erforderlich.
5. Bestehendes Projekt aktualisieren, Änderungen committen und Deployment
   prüfen. Bestehende Domains/DNS und IONOS-Mail-Einträge unverändert lassen.
6. Formular nach Veröffentlichung auf `www.novaireai.de` testen. Zufällige
   Vercel-Preview-Domains sind absichtlich nicht für Formular-POSTs zugelassen.

Nur `public` wird ausgeliefert. Backend-Code, interne Checkliste, QA-Bilder und
Flutter-Code gehören nicht in die öffentliche Ausgabe. `vercel.json` setzt
Sicherheitsheader und eine auf den einzelnen Formular-Endpunkt begrenzte CSP.
`noindex` bleibt erhalten; es ist weder Passwort- noch Zugriffsschutz.

## Beta und Verwaltung

Frist: einschließlich 30. Oktober 2026, 23:59 Uhr deutscher Zeit;
serverseitiger Schluss `2026-10-30T23:00:00Z`. Rund 50 Plätze, keine
automatische Zusage. Unter 16 bewirbt sich ein Elternteil und verwendet seine
eigene E-Mail. Vor Einladung muss die Elternzustimmung geprüft werden.

Bewerbungen liegen privat in Supabase unter
`public.website_beta_applications`. App-Nutzer und Website-Besucher können
sie nicht lesen oder administrieren. Keine automatische Bestätigungsmail,
TestFlight-Einladung, Auswahl durch KI oder Newsletter-Anmeldung.
Pro Kontaktadresse wird eine Bewerbung gespeichert; Geschwister und
Korrekturen werden über den Support bearbeitet.

Details zu Auswahl, Löschung, Deployment und Tests: `BETA-OPERATIONS.md`.
Öffentliche Redaktion-/Entwurfsnotizen wurden entfernt; die rechtliche und
vertragliche Abschlussprüfung bleibt eine interne Betreiberaufgabe.

Halloween-Update: Kürbisranken an ausgewählten Überschriften, Vogelscheuchen
und kleine Kürbisgruppen sind nun eigens generierte, fotorealistische Motive
mit transparentem Hintergrund, lokal und komprimiert als WebP eingebunden.
Sie blockieren keine Bedienelemente und werden bei erhöhtem Kontrast ausgeblendet.
Start- und Beta-Seite haben dezente weiße, gelbe und blaue Hintergrundsterne;
Rechtliches, Support und 404 bleiben frei. Reduzierte Bewegung stoppt das Glimmen.
Nur die Zeile „Endet vor Halloween — damit ihr feiern könnt.“ nutzt lokal
gehostetes Creepster; die Frist bleibt unverändert am 30. Oktober.
Aufbau, Formular und Supabase-Endpunkt bleiben unverändert; der Motivationstext
lädt ausdrücklich zum lockeren Schreiben ein. Grafiken, Prompts und Herkunft
sind in `HALLOWEEN-ASSETS.md` und `ASSETS.md` dokumentiert.

Der mintgrüne Kasten nach dem Absenden bestätigt nur den Bewerbungseingang,
nicht die Auswahl. Eine echte Glückwunsch-/Einladungsansicht ist noch nicht
implementiert. Dafür später einen privaten, abgesicherten Einladungslink
verwenden; keinen öffentlichen Bewerbungsstatus über eine E-Mail-Suche anbieten.

## Dateien

- `public/index.html`: Startseite und Beta-Link.
- `public/beta.html`: Countdown, Formular und Teilnahmehinweise.
- `public/beta.js`: Versand, Fehlerzustände, Elternprozess.
- `public/beta-core.js`: Frist und reine Eingabevalidierung.
- `public/styles.css`: native Systemschrift, lokale Halloween-Akzente und
  separat begrenzte lokale Creepster-Schrift für den Kampagnenhinweis.
- `public/app.js`: bestehendes Menü, Bildansicht und Einblendungen.
- `tools/legal-content.mjs`: Recht-/Supporttexte; danach `npm run build`.
- `public/assets`: lokale Bilder, Logos und dekorative SVGs.
- `../supabase/functions/beta-application`: öffentliches Formular-Gateway;
  die Service-Credentials bleiben ausschließlich im Backend.

Keine Cookies, externen Fonts, Tracking oder Browser-Speicherung der Antworten.
Ein Formular-POST erfolgt erst nach ausdrücklichem Absenden. Es gibt noch keinen
öffentlichen App-Store-Link und keine erfundenen Preise oder Download-Zusagen.

## Tests

```sh
npm run build
npm test
node --check public/app.js
node --check public/beta.js
node --check public/beta-core.js
# Preview in einem zweiten Terminal laufen lassen:
node tools/browser-check.cjs
```

Browser-QA verwendet lokales Playwright (bei Bedarf `PLAYWRIGHT_PATH`), nicht
als Website-Abhängigkeit. Sie prüft 7 Seiten bei 320/390/768/1440 Pixeln,
Navigation, Keyboard-Fokus, kein JS, reduzierte Bewegung, Formularvalidierung,
202/Fehler/Retry/Frist/Doppelversand und unerlaubte Requests. Backend-Antworten
sind dabei gezielt gemockt; Live-Tests sind separat dokumentiert. Bilder und
Bericht werden unter `qa/` erzeugt. Echte Mobile-Safari-Prüfung bleibt sinnvoll.

Der bestehende App-Screenshot-Export ist ein offline Mock-Backend-Test:

```sh
cd /Users/armindaniel/Dev/premium_app
flutter test website/test/capture_app_test.dart \
  --dart-define=PREVIEW_FONTS=/Users/armindaniel/Dev/flutter/bin/cache/artifacts/material_fonts
```

Er zeigt Produktionswidgets mit lokalen Beispieldaten, keine echten Nutzer.
