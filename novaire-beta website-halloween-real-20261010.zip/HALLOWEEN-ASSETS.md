# Halloween-Grafiken und Umsetzung

Stand: 10. Oktober 2026. Drei neue, eigens mit dem eingebauten Imagegen-Werkzeug generierte fotorealistische Motive, keine Stock-Vorlagen oder fotografierten Originalobjekte. Transparenter Hintergrund wurde bei jeder Generierung angefordert. Die Original-PNGs bleiben unverändert im Codex-Ausgabeordner; für die Website wurden sie ausschließlich skaliert und mit Alpha als WebP komprimiert (Sharp, Qualität 88, Alpha-Qualität 100). Keine neue Website-Runtime-Abhängigkeit.

## Eingebundene Dateien

- `/Users/armindaniel/Dev/premium_app/website/public/assets/halloween-pumpkins-real.webp` — 900 × 600, transparenter WebP-Cutout. Original: `/Users/armindaniel/.codex/generated_images/01a0872b-7e2f-70a0-9474-a886ec83630f/exec-bd7ba370-6f9a-4cc7-81dd-24f8720d11fe.png`.
- `/Users/armindaniel/Dev/premium_app/website/public/assets/halloween-scarecrow-real.webp` — 700 × 1050, transparenter WebP-Cutout. Original: `/Users/armindaniel/.codex/generated_images/01a0872b-7e2f-70a0-9474-a886ec83630f/exec-89c16c45-2162-46e9-bcaf-e8dff0e54daf.png`.
- `/Users/armindaniel/Dev/premium_app/website/public/assets/halloween-vine-real.webp` — 1100 × 367, transparenter WebP-Cutout. Original: `/Users/armindaniel/.codex/generated_images/01a0872b-7e2f-70a0-9474-a886ec83630f/exec-07cfdef3-8667-4396-89c3-5cfec8aa66e1.png`.

Die bisherigen flachen SVG-Motive bleiben als unbenutzte Altdateien erhalten, werden auf Start- und Beta-Seite aber nicht mehr eingebunden.

## Verwendete Prompts

### pumpkins

```text
Use case: product-mockup
Asset type: transparent decorative website cutout for a premium black Novaire landing page.
Primary request: One compact cluster of three real autumn pumpkins, including one restrained carved jack-o-lantern with warm candlelight inside, a small pale cream pumpkin and a slightly taller natural orange pumpkin behind it. Natural curled stems and a few real dried pumpkin leaves. Photorealistic premium still-life photography, convincing organic grooves, small surface imperfections and tactile waxy rind, no cartoon.
Composition: wide compact grouping, subjects fully visible, transparent padding, camera at pumpkin level slight three-quarter view. No floor, no horizon, no rectangular backdrop.
Lighting: soft warm side key plus very subtle cool moonlit rim light; restrained vivid rust-orange, not muddy brown; clean realistic detail. Warm gentle candle glow, no scary face.
Constraints: actual transparent background, clean alpha cutout, no text, watermark, sticker outline, emojis, clipart, illustrations, vector shapes, glossy toy/plastic materials, fake graphics or extraneous objects.
```

### scarecrow

```text
Use case: product-mockup
Asset type: single transparent decorative cutout for a premium dark Halloween website.
Primary request: A realistic handcrafted small scarecrow on one weathered wood stake. Full body of one burlap sack head with simple stitched face, naturally woven straw sun hat, a faded dark charcoal-green linen field shirt with worn seams, wisps of real straw emerging at cuffs and neck, slim wood arms angled naturally. Appealing calm seasonal object, no horror.
Style: photorealistic product photography, real fiber texture, visible straw filaments, believable imperfect cloth folds, vintage garden prop rather than flat cartoon or cute game character.
Composition: portrait single subject entirely visible from hat to bottom of stake, no ground, no surrounding scene; transparent padding.
Lighting: controlled soft warm key, fine cool moon rim, enough contrast for black website background. Natural warm tan straw and subtle earthy fabrics.
Constraints: genuinely transparent background, no text, watermark, logos, cartoon geometry, stickers, icons, flat illustration, exaggerated big head, shiny toy materials, full backdrop, or pumpkins.
```

### vine

```text
Use case: product-mockup
Asset type: horizontal transparent pumpkin vine cutout to drape across a few heading letters on a black premium website.
Primary request: A single real thin curling pumpkin vine with elegant loose tendrils, three small realistic dark olive green leaves and one tiny ripe orange pumpkin hanging near the right third. Real botanically plausible stem textures, fibrous dry tendrils, delicate leaf veining. Understated photorealistic botanical still-life.
Composition: very wide thin horizontal garland gently curving upward in the middle; stem and leaves compact, long ends fading naturally through thinner tendrils, everything visible, ample transparent margin. No hanging strings or decorations.
Lighting: soft warm light and subtle cool moon rim, dark olive leaves but legible on black, restrained rust orange gourd.
Constraints: actual transparent background, no text, watermarks, borders, flat vector leaves, cartoon, icons, sticker look, grassy background or additional props.
```

## Sterne und Schrift

72 kleine deterministisch angeordnete weiße, warmgelbe und eisblaue Sterne (48 auf schmalen Geräten) werden einmalig lokal erzeugt. Nur einige glimmen langsam über CSS; kein Animationstimer, Canvas oder Netzwerkdienst. Nur Start- und Beta-Seite haben die erforderliche `seasonal-site`-Klasse. Rechtliches, Support und 404 bleiben frei. Bei reduzierter Bewegung sind Sterne statisch, bei erhöhtem Kontrast ausgeblendet.

Nur die Kampagnenzeile „Endet vor Halloween — damit ihr feiern könnt.“ verwendet lokal gehostetes Creepster Regular. Der Rest bleibt bei der vorhandenen nativen Systemschrift. Schrift und vollständige SIL-OFL-Lizenz: `public/assets/fonts/`; Quellen stehen in `FONT-SOURCES.md`.

Die Bewerbung endet unverändert einschließlich 30. Oktober 2026, 23:59 Uhr deutscher Zeit. Halloween ist am 31. Oktober, daher bewusst „vor Halloween“ statt einer unzutreffenden Behauptung über den Countdown. Keine Änderung am Bewerbungsprotokoll, Supabase, der Auswahl oder der Zusagefunktion.

