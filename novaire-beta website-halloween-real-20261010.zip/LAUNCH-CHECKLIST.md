# Interne Freigabe — wird nicht als Website ausgeliefert

## In diesem Auftrag bestätigt / umgesetzt

- [x] Armin Brnicanin vom Betreiber am 10.10.2026 als alleiniger rechtlicher
  Betreiber bestätigt. Kein Registereintrag, USt-ID oder Rechtsformzusatz erfunden.
- [x] Separate Beta-Seite, rund 50 Plätze, Frist einschließlich 30.10.2026,
  Überraschungs-Dankeschön ohne zugesagten Gegenstand oder Geldwert.
- [x] Unter 16 Bewerbung durch Eltern mit Eltern-Mail ausdrücklich freigegeben.
  Datenbank verhindert Einladung ohne gesetzte `guardian_verified`-Bestätigung.
- [x] Private Supabase-Tabelle und öffentliches abgesichertes Gateway nach
  ausdrücklicher Freigabe veröffentlicht; keine Änderung bestehender Konten/Chats.
- [x] Öffentliche Redaktion-/Entwurfsnotizen entfernt. Sachliche Hinweise auf
  Beta-Fehler und KI-Grenzen beibehalten. Interne Risiken nicht als Werbetext.
- [x] Normale Systemschrift, zurückhaltende lokale Kürbisse, keine Trackingdienste.

## Vor Veröffentlichung / Start weiter prüfen

- [ ] Gewerbeanmeldung, tatsächliche Rechtsform und notwendige Pflichtangaben
  vervollständigen. „CEO“ allein ist kein Rechtsformnachweis.
- [ ] Nutzungs-/Markenrechte an Novaire, KI-Logo und Anbieter-Logos bestätigen.
- [ ] Support-Postfach testen; Zugriffe nur für erforderliche berechtigte Personen.
- [ ] Vercel-/IONOS-/Supabase-Verträge, AVVs, Logs, Backups, Regionen und
  Drittlandübermittlungen bestätigen. Frankfurt ist kein Nachweis, dass sämtliche
  Daten ausschließlich in der EU verarbeitet werden.
- [ ] Gesamte App-Datenverarbeitung mit OpenAI, Anthropic, RevenueCat, Apple
  und weiteren tatsächlichen Diensten gesondert prüfen: Live-Settings, Rollen,
  Aufbewahrung, Audio/Training, Transfers und vollständige Datenschutzerklärung.
- [ ] Elternprüfung vor Einladung organisatorisch festlegen. Formularhäkchen und
  Eltern-Mail sind noch kein verifizierter Sorgeberechtigten-Nachweis; keine
  unnötigen Ausweiskopien einsammeln. Kinderinformationen/Verträge prüfen lassen.
- [ ] Rechtstexte, Rechtsgrundlagen, Minderjährigenverträge, Streitbeilegung und
  ggf. Datenschutz-Folgenabschätzung fachlich prüfen lassen. Code ist keine
  Garantie für einen „DSGVO-konformen“ Betrieb.
- [ ] Überraschung und Einladungsschritte tatsächlich planen; nur Teilnehmenden
  versprochen. Kein bestimmter Geschenk-/Geldwert und keine Gratis-Pro-Zusage.
- [ ] Auskunft/Widerruf/Löschung über Support praktisch organisieren. Status
  `withdrawn` löscht die Daten nicht; bei berechtigter Löschanfrage Datensatz löschen.
- [ ] Spam-Volumen nach Start beobachten; Honeypot und Zähler sind kein CAPTCHA
  und keine verifizierte E-Mail. Bei echtem Missbrauch Schutz gezielt verstärken.
- [ ] App-Screens und angekündigte Funktionen mit aktuellem iPhone-Build abgleichen;
  Website-QA beweist keine Live-Voice-/App-Funktionalität.
- [ ] Mobile Safari auf einem echten iPhone prüfen; lokale Chromium-QA ist getrennt.
- [ ] Aktuelle Website auf bestehendes Vercel-Projekt ausrollen und die öffentlichen
  Domains/Formularverbindung prüfen. Dieses Update ist noch nicht dort veröffentlicht.
- [ ] Bewusst entscheiden, ob `noindex` in HTML/Headers/robots.txt später entfernt
  werden soll. Es schützt nicht vor öffentlichem Zugriff; geschützte Vorschauen
  benötigen tatsächliche Deployment Protection. Keine Wildcard-CORS für Previews.
- [ ] App-Store-Link ergänzen, sobald real verfügbar. Kauf-/Abokonditionen und
  Verbraucherinformationen vor Verkauf separat fertigstellen.

## Nachvollziehbarkeit

Git-Checkpoint vor diesen Änderungen:
`codex/checkpoint-website-beta-20261010`, Commit
`001b7d277a0a1d7ee1ac297990f3e7f58de14213` (nur damaliger Website-Stand;
regulärer Index und übrige lokale App-Änderungen wurden nicht verändert).

Relevante offizielle Quellen, geprüft am 10.10.2026:

- DDG §5: https://www.gesetze-im-internet.de/ddg/__5.html
- DSGVO: https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng
- VSBG §36: https://www.gesetze-im-internet.de/vsbg/__36.html
- Vercel: https://vercel.com/legal/dpa und https://vercel.com/legal/privacy-notice
- Supabase: https://supabase.com/legal/dpa und https://supabase.com/privacy
- Formular-CORS: https://supabase.com/docs/guides/functions/cors
- API-Zugriffsschutz: https://supabase.com/docs/guides/api/securing-your-api

Supabase-Betrieb und tatsächlich ausgeführte Tests stehen in `BETA-OPERATIONS.md`.
